package com.example.bloodaid;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.bloodaid.ui.BankFragment;
import com.example.bloodaid.ui.DonorFragment;
import com.example.bloodaid.ui.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Fragment homeFragment = new HomeFragment();
    private Fragment donorFragment = new DonorFragment();
    private Fragment bankFragment = new BankFragment();
    private Fragment activeFragment;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        fragmentManager = getSupportFragmentManager();

        // Add all fragments once and show only the HomeFragment
        fragmentManager.beginTransaction().add(R.id.container, bankFragment, "bank").hide(bankFragment).commit();
        fragmentManager.beginTransaction().add(R.id.container, donorFragment, "donor").hide(donorFragment).commit();
        fragmentManager.beginTransaction().add(R.id.container, homeFragment, "home").commit();
        activeFragment = homeFragment;

        // Set up bottom navigation listener
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.home) {
                switchFragment(homeFragment);
                return true;
            } else if (itemId == R.id.donor) {
                switchFragment(donorFragment);
                return true;
            } else if (itemId == R.id.bank) {
                switchFragment(bankFragment);
                return true;
            }
            return false;
        });
    }

    private void switchFragment(Fragment fragment) {
        if (fragment != activeFragment) {
            fragmentManager.beginTransaction()
                    .hide(activeFragment)
                    .show(fragment)
                    .commit();
            activeFragment = fragment;
        }
    }
}
