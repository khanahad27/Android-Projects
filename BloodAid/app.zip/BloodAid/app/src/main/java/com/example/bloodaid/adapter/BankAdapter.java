package com.example.bloodaid.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bloodaid.R;
import com.example.bloodaid.model.UserModel1;

import java.util.List;

public class BankAdapter extends RecyclerView.Adapter<BankAdapter.BankViewHolder>{

    private Context context;
    private List<UserModel1> list;

    public BankAdapter(Context context, List<UserModel1> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public BankAdapter.BankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new BankViewHolder(LayoutInflater.from(context).inflate(R.layout.bank_item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull BankAdapter.BankViewHolder holder, int position) {

        holder.Name.setText(list.get(position).getName());
        holder.Phone.setText(list.get(position).getPhone());
        holder.Address.setText(list.get(position).getAddress());
        holder.City.setText(list.get(position).getCity());
        holder.District.setText(list.get(position).getDistrict());
        holder.State.setText(list.get(position).getState());
        holder.Email.setText(list.get(position).getEmail());

    }

    @Override
    public int getItemCount() { return list.size(); }

    public class BankViewHolder extends RecyclerView.ViewHolder {

        TextView Name, Phone, Address, City, District, State, Email;

        public BankViewHolder(@NonNull View itemView){
            super(itemView);

            Name = itemView.findViewById(R.id.Name);
            Phone = itemView.findViewById(R.id.Phone);
            Address = itemView.findViewById(R.id.Address);
            City = itemView.findViewById(R.id.City);
            District = itemView.findViewById(R.id.District);
            State = itemView.findViewById(R.id.State);
            Email = itemView.findViewById(R.id.Email);

        }

    }
}
