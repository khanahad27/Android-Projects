package com.example.bloodaid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bloodaid.MainActivity;
import com.example.bloodaid.R;
import com.example.bloodaid.databinding.ActivityReproBinding;
import com.example.bloodaid.model.UserModel1;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReProActivity extends AppCompatActivity {

    private ActivityReproBinding binding;
    private String name, phone, email, password, address, city, district, state;
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityReproBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("ReProUsers");

        binding.btnBack.setOnClickListener(v -> {
            startActivity(new Intent(ReProActivity.this, RegistrationActivity.class));
            finish();
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                startActivity(new Intent(ReProActivity.this, RegistrationActivity.class));
                finish();
            }
        });

        binding.loginBtn.setOnClickListener(v -> {
            startActivity(new Intent(ReProActivity.this, LoginActivity.class));
            finish();
        });

        binding.RegisterBtn.setOnClickListener(view -> {
            name = binding.inputName.getText().toString().trim();
            phone = binding.inputPhone.getText().toString().trim();
            email = binding.inputEmail.getText().toString().trim();
            password = binding.inputPassword.getText().toString().trim();
            address = binding.inputAddress.getText().toString().trim();
            city = binding.inputCity.getText().toString().trim();
            district = binding.inputDistrict.getText().toString().trim();
            state = binding.inputState.getText().toString().trim();

            if (name.isEmpty()) {
                binding.inputName.setError("Enter Your Name");
                binding.inputName.requestFocus();
            } else if (phone.isEmpty()) {
                binding.inputPhone.setError("Enter Your Phone Number");
                binding.inputPhone.requestFocus();
            } else if (email.isEmpty()) {
                binding.inputEmail.setError("Enter Your Email");
                binding.inputEmail.requestFocus();
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.inputEmail.setError("Enter a valid email address");
                binding.inputEmail.requestFocus();
            } else if (address.isEmpty()) {
                binding.inputAddress.setError("Enter Your Address");
                binding.inputAddress.requestFocus();
            } else if (city.isEmpty()) {
                binding.inputCity.setError("Enter Your City");
                binding.inputCity.requestFocus();
            } else if (district.isEmpty()) {
                binding.inputDistrict.setError("Enter Your District");
                binding.inputDistrict.requestFocus();
            } else if (state.isEmpty()) {
                binding.inputState.setError("Enter Your State");
                binding.inputState.requestFocus();
            } else if (password.isEmpty()) {
                binding.inputPassword.setError("Enter Your Password");
                binding.inputPassword.requestFocus();
            } else if (password.length() < 6) {
                binding.inputPassword.setError("Password must be at least 6 characters");
                binding.inputPassword.requestFocus();
            } else {
                checkIfReProUserExists();
            }
        });

        TextInputLayout passwordLayout = binding.inputPasswordLayout;
        EditText passwordField = binding.inputPassword;

        passwordLayout.setEndIconDrawable(R.drawable.ic_eye_closed);
        passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance());

        passwordLayout.setEndIconOnClickListener(v -> {
            if (passwordField.getTransformationMethod() instanceof PasswordTransformationMethod) {
                passwordField.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                passwordLayout.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance());
                passwordLayout.setEndIconDrawable(R.drawable.ic_eye_closed);
            }
            passwordField.setSelection(passwordField.getText().length());
        });

    }

    // ✅ Check if user already exists in ReProUsers
    private void checkIfReProUserExists() {
        DatabaseReference reProRef = FirebaseDatabase.getInstance().getReference("ReProUsers");
        reProRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(ReProActivity.this, "This email is already registered as a RePro.", Toast.LENGTH_LONG).show();
                } else {
                    checkIfDonorExists();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReProActivity.this, "Error checking user data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ✅ Check if user is already registered as a Donor
    private void checkIfDonorExists() {
        DatabaseReference donorRef = FirebaseDatabase.getInstance().getReference("Users").child("Donors");
        donorRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(ReProActivity.this, "You are already registered as a Donor. Cannot register as a RePro.", Toast.LENGTH_LONG).show();
                } else {
                    registerUser(email, password);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReProActivity.this, "Error checking donor data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ✅ Register ReProUser
    private void registerUser(String email, String password) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        insertData();
                    } else {
                        Toast.makeText(ReProActivity.this, "Registration Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    // ✅ Insert ReProUser Data into Firebase (including password)
    private void insertData() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(ReProActivity.this, "Error: User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = auth.getCurrentUser().getUid();
        UserModel1 userModel1 = new UserModel1(name, phone, email, password, address, city, district, state); // ✅ Includes Password

        FirebaseDatabase.getInstance().getReference("ReProUsers").child(userId)
                .setValue(userModel1)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(ReProActivity.this, "Blood Bank Registration Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ReProActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(ReProActivity.this, "Failed to save data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
