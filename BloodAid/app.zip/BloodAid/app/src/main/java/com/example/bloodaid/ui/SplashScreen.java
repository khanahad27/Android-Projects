package com.example.bloodaid.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.example.bloodaid.R;
import com.google.firebase.auth.FirebaseAuth;

@SuppressLint("CustomSplashScreen")
public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Handler handler = new Handler();
        handler.postDelayed(() -> {
            if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                // ✅ User is already signed up → Redirect to Login Page
                startActivity(new Intent(SplashScreen.this, LoginActivity.class));
            } else {
                // ❌ No user found → Redirect to Registration Page
                startActivity(new Intent(SplashScreen.this, RegistrationActivity.class));
            }
            finish(); // Close SplashScreen
        }, 2000);
    }
}
