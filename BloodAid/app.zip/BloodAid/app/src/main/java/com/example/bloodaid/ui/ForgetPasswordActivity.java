// ForgetPasswordActivity.java
package com.example.bloodaid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bloodaid.R;
import com.example.bloodaid.databinding.ActivityForgetPasswordBinding;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;

public class ForgetPasswordActivity extends AppCompatActivity {

    private ActivityForgetPasswordBinding binding;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityForgetPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();

        togglePasswordVisibility(binding.inputPasswordLayout1, binding.inputNewPassword);
        togglePasswordVisibility(binding.inputPasswordLayout2, binding.inputConfirmPassword);

        binding.btnResetPassword.setOnClickListener(v -> {
            String email = binding.inputEmail.getText().toString().trim();

            if (email.isEmpty()) {
                binding.inputEmail.setError("Enter your email");
                binding.inputEmail.requestFocus();
                return;
            }

            auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Password reset email sent. Check your inbox.", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(ForgetPasswordActivity.this, LoginActivity.class));
                            finish();
                        } else {
                            Toast.makeText(this, "Failed to send reset email: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });

        binding.btnBack.setOnClickListener(v -> {
            startActivity(new Intent(ForgetPasswordActivity.this, LoginActivity.class));
            finish();
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                startActivity(new Intent(ForgetPasswordActivity.this, LoginActivity.class));
                finish();
            }
        });
    }

    private void togglePasswordVisibility(TextInputLayout layout, EditText field) {
        layout.setEndIconDrawable(R.drawable.ic_eye_closed);
        field.setTransformationMethod(PasswordTransformationMethod.getInstance());
        layout.setEndIconOnClickListener(v -> {
            if (field.getTransformationMethod() instanceof PasswordTransformationMethod) {
                field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                layout.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                field.setTransformationMethod(PasswordTransformationMethod.getInstance());
                layout.setEndIconDrawable(R.drawable.ic_eye_closed);
            }
            field.setSelection(field.getText().length());
        });
    }
}
