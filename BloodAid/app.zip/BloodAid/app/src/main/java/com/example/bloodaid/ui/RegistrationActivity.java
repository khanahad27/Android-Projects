package com.example.bloodaid.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.bloodaid.databinding.ActivityRegistrationBinding;

public class RegistrationActivity extends AppCompatActivity {

    private ActivityRegistrationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistrationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.donorBtn.setOnClickListener(v -> {
            startActivity(new Intent(RegistrationActivity.this, DonorActivity.class));
        });

        binding.bloodbankBtn.setOnClickListener(v -> {
            startActivity(new Intent(RegistrationActivity.this, ReProActivity.class));
        });

        binding.loginBtn.setOnClickListener(v -> {
            startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
        });
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        // ✅ Show exit confirmation dialog BEFORE calling super.onBackPressed()
        new AlertDialog.Builder(this)
                .setTitle("Exit App")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", (dialog, which) -> finishAffinity()) // Close the app
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss()) // Dismiss dialog
                .show();
    }
}