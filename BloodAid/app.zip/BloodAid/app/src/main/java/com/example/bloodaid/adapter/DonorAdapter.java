package com.example.bloodaid.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bloodaid.R;
import com.example.bloodaid.model.UserModel2;

import java.util.List;

public class DonorAdapter extends RecyclerView.Adapter<DonorAdapter.DonorViewHolder>{

    private Context context;
    private List<UserModel2> list;

    public DonorAdapter(Context context, List<UserModel2> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public DonorAdapter.DonorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DonorViewHolder(LayoutInflater.from(context).inflate(R.layout.donor_item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull DonorAdapter.DonorViewHolder holder, int position) {

        holder.Name.setText(list.get(position).getName());
        holder.Age.setText(list.get(position).getAge());
        holder.Blood.setText(list.get(position).getBloodGroup());
        holder.Gender.setText(list.get(position).getGender());
        holder.Phone.setText(list.get(position).getPhone());
        holder.Address.setText(list.get(position).getAddress());
        holder.City.setText(list.get(position).getCity());
        holder.District.setText(list.get(position).getDistrict());
        holder.State.setText(list.get(position).getState());
        holder.Email.setText(list.get(position).getEmail());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class DonorViewHolder extends RecyclerView.ViewHolder {

        TextView Name, Age, Blood, Gender, Phone, Address, City, District, State, Email;

        public DonorViewHolder(@NonNull View itemView) {
            super(itemView);

            Name = itemView.findViewById(R.id.Name);
            Age = itemView.findViewById(R.id.Age);
            Blood = itemView.findViewById(R.id.Blood);
            Gender = itemView.findViewById(R.id.Gender);
            Phone = itemView.findViewById(R.id.Phone);
            Address = itemView.findViewById(R.id.Address);
            City = itemView.findViewById(R.id.City);
            District = itemView.findViewById(R.id.District);
            State = itemView.findViewById(R.id.State);
            Email = itemView.findViewById(R.id.Email);

        }
    }
}
