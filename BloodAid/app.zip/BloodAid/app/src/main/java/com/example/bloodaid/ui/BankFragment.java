package com.example.bloodaid.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.bloodaid.adapter.BankAdapter;
import com.example.bloodaid.databinding.FragmentBankBinding;
import com.example.bloodaid.model.UserModel1;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BankFragment extends Fragment {

    private FragmentBankBinding binding;
    private List<UserModel1> list;
    private BankAdapter adapter;
    private DatabaseReference datareference;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentBankBinding.inflate(inflater, container, false);

        list = new ArrayList<>();
        adapter = new BankAdapter(requireContext(), list);
        binding.recyclerView.setAdapter(adapter);
        datareference = FirebaseDatabase.getInstance().getReference("ReProUsers");

        datareference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    UserModel1 userModel1 = dataSnapshot.getValue(UserModel1.class);
                    list.add(userModel1);
                    binding.recyclerView.setAdapter(adapter);
                    binding.progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        // Handle back press to navigate to HomeFragment
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        navigateToHomeFragment();
                    }
                });

        return binding.getRoot();
    }

    private void navigateToHomeFragment() {
        NavHostFragment.findNavController(this).navigateUp();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Avoid memory leaks
    }
}
