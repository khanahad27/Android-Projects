package com.example.careconnect.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.careconnect.adapter.CategoryAdapter;
import com.example.careconnect.adapter.TopDoctorAdapter;
import com.example.careconnect.R;
import com.example.careconnect.ViewModel.MainViewModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    private TextView tvName;
    private DatabaseReference userRef;
    private MainViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvName = view.findViewById(R.id.tvName);
        viewModel = new MainViewModel();

        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            String userId = currentUser.getUid();
            userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);
            loadUserData();
        } else {
            Toast.makeText(getContext(), "User not logged in", Toast.LENGTH_SHORT).show();
        }

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                new AlertDialog.Builder(requireContext())
                        .setTitle("Exit App")
                        .setMessage("Are you sure you want to exit?")
                        .setPositiveButton("Yes", (dialog, which) -> requireActivity().finishAffinity()) // ✅ Properly exits the app
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
        initCategory(view);
        initTopDoctors(view);
    }

    private void loadUserData() {
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    tvName.setText("Hi, " + (name != null ? name : "User ") + "!");
                } else {
                    Toast.makeText(getContext(), "User data not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initCategory(View view) {
        View progressBarCategory = view.findViewById(R.id.progressBarCategory);
        progressBarCategory.setVisibility(View.VISIBLE);
        viewModel.getCategory().observe(getViewLifecycleOwner(), categories -> {
            androidx.recyclerview.widget.RecyclerView recyclerView = view.findViewById(R.id.viewCategory);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
            recyclerView.setAdapter(new CategoryAdapter(requireContext(), categories)); // Pass Context
            progressBarCategory.setVisibility(View.GONE);
        });
        viewModel.loadCategory();
    }

    private void initTopDoctors(View view) {
        View progressBarTopDoctor = view.findViewById(R.id.progressBarTopDoctor);
        progressBarTopDoctor.setVisibility(View.VISIBLE);
        viewModel.getDoctors().observe(getViewLifecycleOwner(), doctors -> {
            androidx.recyclerview.widget.RecyclerView recyclerView = view.findViewById(R.id.recyclerViewTopDoctor);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
            recyclerView.setAdapter(new TopDoctorAdapter(requireContext(), doctors)); // Pass Context
            progressBarTopDoctor.setVisibility(View.GONE);
        });
        viewModel.loadDoctors();

    }

}
