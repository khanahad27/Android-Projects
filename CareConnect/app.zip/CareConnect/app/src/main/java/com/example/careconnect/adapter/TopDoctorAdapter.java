package com.example.careconnect.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.example.careconnect.DetailActivity;
import com.example.careconnect.model.DoctorModel;
import com.example.careconnect.databinding.ViewholderTopDoctorBinding;
import java.util.List;

public class TopDoctorAdapter extends RecyclerView.Adapter<TopDoctorAdapter.ViewHolder> {
    private List<DoctorModel> items;
    private final Context context;

    public TopDoctorAdapter(Context context, List<DoctorModel> items) {
        this.context = context;
        this.items = items;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ViewholderTopDoctorBinding binding;

        public ViewHolder(ViewholderTopDoctorBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ViewholderTopDoctorBinding binding = ViewholderTopDoctorBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DoctorModel doctor = items.get(position);
        holder.binding.nameTxt.setText(doctor.getName());
        holder.binding.specialTxt.setText(doctor.getSpecial());
        holder.binding.scoreTxt.setText(String.valueOf(doctor.getRating()));
        holder.binding.yearTxt.setText(doctor.getExperience() + " Year");

        Glide.with(holder.itemView.getContext())
                .load(doctor.getPicture())
                .apply(new RequestOptions().transform(new CenterCrop()))
                .into(holder.binding.img);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("object", doctor);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }
}
