package com.example.careconnect.model;

public class UserModel1 {

    private String name, age, bloodGroup, gender, phone, address, email, password;

    // 🔹 Default (No-Argument) Constructor (Needed for Firebase)
    public UserModel1() {}

    // ✅ Correct constructor with properly ordered assignments
    public UserModel1(String name, String age, String bloodGroup, String gender, String phone,
                      String address, String email, String password) {
        this.name = name;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.gender = gender;
        this.phone = phone;  // ✅ Correct placement after gender
        this.address = address;
        this.email = email;
        this.password = password;
    }

    // ✅ Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
