
package com.example.careconnect.model;

import android.os.Parcel;
import android.os.Parcelable;

public class DoctorModel implements Parcelable {
    private String  name, special, patients, biography, address, site, mobile, location, picture;
    private float rating;
    private long id, experience;  // Matches Firebase data type

    // No-argument constructor (Required by Firebase)
    public DoctorModel() {}

    // Parameterized constructor
    public DoctorModel(long id, String name, String special, String patients, String biography,
                       String address, String site, String mobile, String location,
                       String picture, float rating, long experience) {
        this.id = id;
        this.name = name;
        this.special = special;
        this.patients = patients;
        this.biography = biography;
        this.address = address;
        this.site = site;
        this.mobile = mobile;
        this.location = location;
        this.picture = picture;
        this.rating = rating;
        this.experience = experience;
    }

    protected DoctorModel(Parcel in) {
        id = in.readLong();
        name = in.readString();
        special = in.readString();
        patients = in.readString();  // Changed from int to String
        biography = in.readString();
        address = in.readString();
        site = in.readString();
        mobile = in.readString();  // Changed from long to String
        location = in.readString();
        picture = in.readString();
        rating = in.readFloat();
        experience = in.readInt();
    }

    public static final Creator<DoctorModel> CREATOR = new Creator<DoctorModel>() {
        @Override
        public DoctorModel createFromParcel(Parcel in) {
            return new DoctorModel(in);
        }

        @Override
        public DoctorModel[] newArray(int size) {
            return new DoctorModel[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(name);
        dest.writeString(special);
        dest.writeString(patients);  // Changed from int to String
        dest.writeString(biography);
        dest.writeString(address);
        dest.writeString(site);
        dest.writeString(mobile);  // Changed from long to String
        dest.writeString(location);
        dest.writeString(picture);
        dest.writeFloat(rating);
        dest.writeLong(experience);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // Getters
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getSpecial() { return special; }
    public String getPatients() { return patients; } // Updated to String
    public String getBiography() { return biography; }
    public String getAddress() { return address; }
    public String getSite() { return site; }
    public String getMobile() { return mobile; } // Updated to String
    public String getLocation() { return location; }
    public String getPicture() { return picture; }
    public float getRating() { return rating; }
    public long getExperience() { return experience; } // Correctly kept as int

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setSpecial(String special) { this.special = special; }
    public void setPatients(String patients) { this.patients = patients; } // Updated to String
    public void setBiography(String biography) { this.biography = biography; }
    public void setAddress(String address) { this.address = address; }
    public void setSite(String site) { this.site = site; }
    public void setMobile(String mobile) { this.mobile = mobile; } // Updated to String
    public void setLocation(String location) { this.location = location; }
    public void setPicture(String picture) { this.picture = picture; }
    public void setRating(float rating) { this.rating = rating; }
    public void setExperience(long experience) { this.experience = experience; }
}
