
package com.example.careconnect.ViewModel;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.careconnect.model.CategoryModel;
import com.example.careconnect.model.DoctorModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {

    private final FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private final MutableLiveData<List<CategoryModel>> _category = new MutableLiveData<>();
    private final MutableLiveData<List<DoctorModel>> _doctors = new MutableLiveData<>();

    public LiveData<List<CategoryModel>> getCategory() {
        return _category;
    }

    public LiveData<List<DoctorModel>> getDoctors() {
        return _doctors;
    }

    public void loadCategory() {
        DatabaseReference ref = firebaseDatabase.getReference("Category");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<CategoryModel> lists = new ArrayList<>();
                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    CategoryModel category = childSnapshot.getValue(CategoryModel.class);
                    if (category != null) {
                        // Ensure ID is properly converted to String if stored as Long
                        Object idValue = childSnapshot.child("id").getValue();
                        if (idValue instanceof Long) {
                            category.setId((Long) idValue);
                        }
                        lists.add(category);
                    }
                }
                _category.setValue(lists);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.err.println("Error loading categories: " + error.getMessage());
            }
        });
    }

    public void loadDoctors() {
        DatabaseReference ref = firebaseDatabase.getReference("Doctors");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<DoctorModel> lists = new ArrayList<>();
                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    DoctorModel doctor = childSnapshot.getValue(DoctorModel.class);
                    if (doctor != null) {
                        // Ensure ID is properly converted to String if stored as Long
                        Object idValue = childSnapshot.child("id").getValue();
                        if (idValue instanceof Long) {
                            doctor.setId((Long) idValue); // Directly pass the long value
                        }
                        lists.add(doctor);
                    }
                }
                _doctors.setValue(lists);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.err.println("Error loading doctors: " + error.getMessage());
            }
        });
    }

}
