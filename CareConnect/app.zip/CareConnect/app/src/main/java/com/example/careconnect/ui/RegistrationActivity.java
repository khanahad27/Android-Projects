package com.example.careconnect.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.careconnect.MainActivity;
import com.example.careconnect.R;
import com.example.careconnect.databinding.ActivityRegistrationBinding;
import com.example.careconnect.model.UserModel1;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegistrationActivity extends AppCompatActivity {

    private ActivityRegistrationBinding binding;
    private String name, age, bloodGroup, gender, phone, address, email, password;
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistrationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users"); // Initialize before authentication

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
                finish();
            }
        });

        binding.loginBtn.setOnClickListener(v -> {
            startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
            finish();
        });

        binding.RegisterBtn.setOnClickListener(view -> {
            name = binding.inputName.getText().toString().trim();
            phone = binding.inputPhone.getText().toString().trim();
            age = binding.inputAge.getText().toString().trim();
            bloodGroup = binding.inputBloodGroup.getText().toString().trim();
            gender = binding.inputGender.getText().toString().trim();
            address = binding.inputAddress.getText().toString().trim();
            email = binding.inputEmail.getText().toString().trim();
            password = binding.inputPassword.getText().toString().trim();

            if (TextUtils.isEmpty(name)) {
                binding.inputName.setError("Enter Your Name");
                binding.inputName.requestFocus();
            } else if (TextUtils.isEmpty(age)) {
                binding.inputAge.setError("Enter Your Age");
                binding.inputAge.requestFocus();
            } else if (!TextUtils.isDigitsOnly(age)) {
                binding.inputAge.setError("Enter a valid age");
                binding.inputAge.requestFocus();
            } else if (TextUtils.isEmpty(bloodGroup)) {
                binding.inputBloodGroup.setError("Select Your Blood Group");
                binding.inputBloodGroup.requestFocus();
            } else if (TextUtils.isEmpty(gender)) {
                binding.inputGender.setError("Select Your Gender");
                binding.inputGender.requestFocus();
            } else if (TextUtils.isEmpty(phone)) {
                binding.inputPhone.setError("Enter Your Phone Number");
                binding.inputPhone.requestFocus();
            } else if (phone.length() != 10) {
                binding.inputPhone.setError("Enter a valid 10-digit phone number");
                binding.inputPhone.requestFocus();
            } else if (TextUtils.isEmpty(email)) {
                binding.inputEmail.setError("Enter Your Email");
                binding.inputEmail.requestFocus();
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.inputEmail.setError("Enter a valid email address");
                binding.inputEmail.requestFocus();
            } else if (TextUtils.isEmpty(password)) {
                binding.inputPassword.setError("Enter Your Password");
                binding.inputPassword.requestFocus();
            } else if (password.length() < 6) {
                binding.inputPassword.setError("Password must be at least 6 characters");
                binding.inputPassword.requestFocus();
            } else {
                checkIfUserExists();
            }
        });

        TextInputLayout passwordLayout = binding.inputPasswordLayout;
        EditText passwordField = binding.inputPassword;

        passwordLayout.setEndIconDrawable(R.drawable.ic_eye_closed);
        passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance());

        passwordLayout.setEndIconOnClickListener(v -> {
            if (passwordField.getTransformationMethod() instanceof PasswordTransformationMethod) {
                passwordField.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                passwordLayout.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance());
                passwordLayout.setEndIconDrawable(R.drawable.ic_eye_closed);
            }
            passwordField.setSelection(passwordField.getText().length());
        });

    }

    private void checkIfUserExists() {
        DatabaseReference donorRef = FirebaseDatabase.getInstance().getReference("Users");
        donorRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(RegistrationActivity.this, "This email is already registered as a User.", Toast.LENGTH_LONG).show();
                } else {
                    registerUser(email, password);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RegistrationActivity.this, "Error checking user data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ✅ Register Donor
    private void registerUser(String email, String password) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        insertData();
                    } else {
                        Toast.makeText(RegistrationActivity.this, "Registration Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    // ✅ Insert Donor Data into Firebase
    private void insertData() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(RegistrationActivity.this, "Error: User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = auth.getCurrentUser().getUid();
        UserModel1 userModel1 = new UserModel1(name, age, bloodGroup, gender, phone, address, email, password);

        FirebaseDatabase.getInstance().getReference("Users").child(userId)
                .setValue(userModel1)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(RegistrationActivity.this, "Donor Registration Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegistrationActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(RegistrationActivity.this, "Failed to save data: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
