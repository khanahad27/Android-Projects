package com.example.careconnect;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.example.careconnect.model.DoctorModel;
import com.example.careconnect.databinding.ActivityDetailBinding;

public class DetailActivity extends AppCompatActivity {
    private ActivityDetailBinding binding;
    private DoctorModel item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getBundle();
    }

    private void getBundle() {
        item = getIntent().getParcelableExtra("object");
        if (item == null) return;

        binding.titleTxt.setText(item.getName());
        binding.specialTxt.setText(item.getSpecial());
        binding.patiensTxt.setText(item.getPatients());
        binding.bioTxt.setText(item.getBiography());
        binding.addressTxt.setText(item.getAddress());
        binding.expriencsTxt.setText(item.getExperience() + " Years");
        binding.ratingTxt.setText(String.valueOf(item.getRating()));

        binding.backBtn.setOnClickListener(v -> finish());

        binding.websiteBtn.setOnClickListener(v -> {
            if (item.getSite() == null || item.getSite().trim().isEmpty()) {
                Toast.makeText(this, "Website not available", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getSite().trim()));
            startActivity(i);
        });

        binding.messageBtn.setOnClickListener(v -> {
            String phoneNumber = item.getMobile();

            if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
                Toast.makeText(v.getContext(), "Phone number not available", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri uri = Uri.parse("smsto:" + Uri.encode(phoneNumber.trim())); // Encode in case of special characters
            Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
            intent.putExtra("sms_body", "the SMS text");

            if (intent.resolveActivity(v.getContext().getPackageManager()) != null) {
                v.getContext().startActivity(intent);
            } else {
                Toast.makeText(v.getContext(), "No SMS app found", Toast.LENGTH_SHORT).show();
            }
        });

        binding.makeBtn.setOnClickListener(v -> {
            if (item.getMobile() == null || item.getMobile().trim().isEmpty()) {
                Toast.makeText(this, "Phone number not available", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri uri = Uri.parse("tel:" + item.getMobile().trim());
            Intent intent = new Intent(Intent.ACTION_DIAL, uri);
            startActivity(intent);
        });

        binding.directionBtn.setOnClickListener(v -> {
            if (item.getLocation() == null || item.getLocation().trim().isEmpty()) {
                Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getLocation().trim()));
            startActivity(intent);
        });

        binding.shareBtn.setOnClickListener(v -> {
            String name = item.getName() != null ? item.getName() : "Unknown";
            String address = item.getAddress() != null ? item.getAddress() : "No address provided";
            String mobile = item.getMobile() != null ? item.getMobile() : "No contact info";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, name);
            intent.putExtra(Intent.EXTRA_TEXT, name + "\n" + address + "\n" + mobile);

            startActivity(Intent.createChooser(intent, "Choose One"));
        });

        if (item.getPicture() != null && !item.getPicture().trim().isEmpty()) {
            Glide.with(this)
                    .load(item.getPicture().trim())
                    .into(binding.img);
        }
    }
}
