package com.example.careconnect;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.careconnect.ui.AboutFragment;
import com.example.careconnect.ui.AccountFragment;
import com.example.careconnect.ui.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Fragment homeFragment = new HomeFragment();
    private Fragment aboutFragment = new AboutFragment();
    private Fragment accountFragment = new AccountFragment();
    private Fragment activeFragment;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        fragmentManager = getSupportFragmentManager();

        // 🔥 FIX: Correct Fragment Container ID (Changed "container" to "fragment_container")
        fragmentManager.beginTransaction().add(R.id.fragment_container, aboutFragment, "about").hide(aboutFragment).commit();
        fragmentManager.beginTransaction().add(R.id.fragment_container, accountFragment, "account").hide(accountFragment).commit();
        fragmentManager.beginTransaction().add(R.id.fragment_container, homeFragment, "home").commit();
        activeFragment = homeFragment;

        // Bottom Navigation Listener
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.home) {
                switchFragment(homeFragment);
                return true;
            } else if (itemId == R.id.about) {
                switchFragment(aboutFragment);
                return true;
            } else if (itemId == R.id.acc) {
                switchFragment(accountFragment);
                return true;
            }
            return false;
        });
    }

    private void switchFragment(Fragment fragment) {
        if (fragment != activeFragment) {
            fragmentManager.beginTransaction()
                    .hide(activeFragment)
                    .show(fragment)
                    .commit();
            activeFragment = fragment;
        }
    }
}
