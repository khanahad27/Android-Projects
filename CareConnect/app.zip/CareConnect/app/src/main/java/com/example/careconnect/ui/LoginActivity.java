// LoginActivity.java
package com.example.careconnect.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.careconnect.MainActivity;
import com.example.careconnect.R;
import com.example.careconnect.databinding.ActivityLoginBinding;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        togglePasswordVisibility(binding.inputPasswordLayout, binding.inputPassword);

        binding.loginBtn.setOnClickListener(v -> {
            String email = binding.inputEmail.getText().toString().trim();
            String password = binding.inputPassword.getText().toString().trim();

            if (email.isEmpty()) {
                binding.inputEmail.setError("Enter your email");
                binding.inputEmail.requestFocus();
                return;
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.inputEmail.setError("Enter a valid email address");
                binding.inputEmail.requestFocus();
                return;
            }
            if (password.isEmpty()) {
                binding.inputPassword.setError("Enter your password");
                binding.inputPassword.requestFocus();
                return;
            }

            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = auth.getCurrentUser();
                            if (user != null) {
                                updatePasswordInRealtimeDatabase(user.getUid(), password);

                                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "Authentication Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });

        binding.forgotBtn.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, ForgetPasswordActivity.class));
        });

        binding.SignupBtn.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
        });

    }

    private void updatePasswordInRealtimeDatabase(String userId, String newPassword) {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // First, check if the user exists in "Users"
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // User exists in "Users" -> Update password only here
                    usersRef.child("password").setValue(newPassword)
                            .addOnSuccessListener(aVoid -> Log.d("updatePassword", "Password updated in Users"))
                            .addOnFailureListener(e -> Log.e("updatePassword", "Failed to update password in Users: " + e.getMessage()));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("updatePassword", "Error checking Users: " + databaseError.getMessage());
            }
        });
    }

    private void togglePasswordVisibility(TextInputLayout layout, EditText field) {
        layout.setEndIconDrawable(R.drawable.ic_eye_closed);
        field.setTransformationMethod(PasswordTransformationMethod.getInstance());
        layout.setEndIconOnClickListener(v -> {
            if (field.getTransformationMethod() instanceof PasswordTransformationMethod) {
                field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                layout.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                field.setTransformationMethod(PasswordTransformationMethod.getInstance());
                layout.setEndIconDrawable(R.drawable.ic_eye_closed);
            }
            field.setSelection(field.getText().length());
        });
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        // ✅ Show exit confirmation dialog BEFORE calling super.onBackPressed()
        new AlertDialog.Builder(this)
                .setTitle("Exit App")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", (dialog, which) -> finishAffinity()) // Close the app
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss()) // Dismiss dialog
                .show();
    }

}
